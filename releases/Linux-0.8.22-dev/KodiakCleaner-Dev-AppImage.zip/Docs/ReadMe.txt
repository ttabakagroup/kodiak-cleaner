Kodiak Cleaner for Linux
========================

Not a Crap Cleaner. A Cleaner App, Built Around What Matters.

Kodiak Cleaner for Linux is a small, honest cleaner by Ted Tabaka. It removes caches, temporary files, logs and package downloads, and lists everything that starts automatically on your computer (Triggers) so you can turn it off or remove it. It has no telemetry, ads, upsells or background services, and it is free and open source under the MIT License.

Beta software: use at your own risk. Kodiak Cleaner deletes things by design, so analyze before you clean, read each caution, and keep your own backups of anything important.

What You Need
-------------

- A 64-bit Linux desktop with Python 3.10 or newer, GTK 4 and libadwaita (GNOME desktops already have them)
- Debian, Ubuntu, Linux Mint: python3-gi gir1.2-gtk-4.0 gir1.2-adw-1
- Fedora: python3-gobject gtk4 libadwaita
- Arch: python-gobject gtk4 libadwaita
- Supporter codes also need python3-cryptography
- Your password only for system-wide items (Kodiak Cleaner asks once per batch)

Install
-------

- Debian package (Debian 12, Ubuntu 22.04, Linux Mint 21 and newer): double-click KodiakCleaner-Dev-amd64.deb to install it with your software center, or run: sudo apt install ./KodiakCleaner-Dev-amd64.deb. Then start Kodiak Cleaner for Linux from your applications menu.
- AppImage (any distribution): right-click KodiakCleaner-Dev-x86_64.AppImage, open Properties and allow it to run as a program (or run: chmod +x KodiakCleaner-Dev-x86_64.AppImage), then double-click it. FUSE must be available, as for any AppImage (libfuse2 on Ubuntu 22.04 and later).

Update Without Losing Anything
------------------------------

Your settings are in ~/.config/kodiak-cleaner and your Triggers History is in ~/.local/share/kodiak-cleaner. Neither is touched by an update, and both work with either download.

- Debian package: install the new .deb the same way; it replaces the old version.
- AppImage: replace the old .AppImage with the new one.

After an update, What's New shows everything that changed since your previous version. The full history is in Changelog.txt.

Uninstall
---------

- Debian package: remove Kodiak Cleaner for Linux in your software center, or run: sudo apt remove kodiak-cleaner
- AppImage: delete the .AppImage file.

To remove your settings and history too, delete ~/.config/kodiak-cleaner and ~/.local/share/kodiak-cleaner.

Privacy
-------

Everything stays on your computer, and Kodiak Cleaner sends nothing on its own. It never goes online by itself. Privacy.txt has the details.

These Documents
---------------

- Changelog.txt: every change, newest first
- Download.url: the newest download on GitHub
- Homepage.url: the Kodiak Cleaner website
- License.txt: the MIT License
- Privacy.txt: the privacy policy
- ReadMe.txt: this file
- TermsOfUse.txt: the Terms of Use

Help and Feedback
-----------------

- Feedback, bug reports and feature requests: Settings > Contact & Feedback, or the contact form at https://www.kodiakcleaner.app/contact/
- Website: https://www.kodiakcleaner.app/
- Source code and releases: https://github.com/ttabakagroup/kodiakcleaner-linux
- Say thanks: https://ko-fi.com/s/aabd61b988

Copyright © 2026 Ted Tabaka. Free and open source under the MIT License.
